// pages/community/community.js
const api = require('../../api/api.js');
const app = getApp();

Page({
  data: {
    // Tab切换
    activeTab: 0,
    tabs: ['推荐', '关注', '话题'],

    // 话题分类
    topics: [],
    activeTopicId: 0,

    // 帖子列表
    posts: [],
    page: 1,
    pageSize: 10,
    hasMore: true,
    loading: false,

    // 用户信息
    userInfo: null,

    // 筛选排序
    sortOptions: [
      { id: 'recommend', name: '推荐' },
      { id: 'latest', name: '最新' },
      { id: 'hot', name: '最热' }
    ],
    currentSort: 'recommend'
  },

  onLoad: function (options) {
    // 获取传递的参数
    if (options.topicId) {
      this.setData({ activeTopicId: parseInt(options.topicId) });
    }

    // 获取用户信息
    this.setData({ userInfo: app.globalData.userInfo });

    // 加载数据
    this.loadTopics();
    this.loadPosts();
  },

  onShow: function () {
    // 更新用户信息
    this.setData({ userInfo: app.globalData.userInfo });
  },

  onReachBottom: function () {
    // 加载更多
    if (this.data.hasMore && !this.data.loading) {
      this.loadPosts(true);
    }
  },

  onPullDownRefresh: function () {
    // 下拉刷新
    this.setData({ page: 1, posts: [], hasMore: true });
    Promise.all([this.loadTopics(), this.loadPosts()]).finally(() => {
      wx.stopPullDownRefresh();
    });
  },

  // ========== Tab切换 ==========
  switchTab: function (e) {
    const index = e.currentTarget.dataset.index;
    this.setData({
      activeTab: index,
      page: 1,
      posts: [],
      hasMore: true
    });

    if (index === 2) {
      // 话题页面
      this.loadTopicsList();
    } else {
      this.loadPosts();
    }
  },

  // ========== 加载话题分类 ==========
  loadTopics: function () {
    api.getCommunityTopics().then(res => {
      if (res.code === 0) {
        this.setData({ topics: res.data || [] });
      }
    }).catch(err => {
      console.error('加载话题分类失败', err);
    });
  },

  // ========== 加载话题广场 ==========
  loadTopicsList: function () {
    api.getTopicsList().then(res => {
      if (res.code === 0) {
        this.setData({ topics: res.data || [] });
      }
    }).catch(err => {
      console.error('加载话题列表失败', err);
    });
  },

  // ========== 话题分类切换 ==========
  selectTopic: function (e) {
    const topicId = e.currentTarget.dataset.id;
    this.setData({
      activeTopicId: topicId,
      page: 1,
      posts: [],
      hasMore: true
    });
    this.loadPosts();
  },

  // ========== 加载帖子列表 ==========
  loadPosts: function (loadMore = false) {
    if (this.data.loading) return;

    this.setData({ loading: true });

    const params = {
      page: loadMore ? this.data.page + 1 : 1,
      pageSize: this.data.pageSize,
      sort: this.data.currentSort,
      topicId: this.data.activeTopicId || null,
      tab: this.data.activeTab === 1 ? 'follow' : 'recommend'
    };

    api.getPostList(params).then(res => {
      if (res.code === 0) {
        const newPosts = res.data.list || [];
        this.setData({
          posts: loadMore ? [...this.data.posts, ...newPosts] : newPosts,
          page: params.page,
          hasMore: newPosts.length >= this.data.pageSize
        });
      }
    }).catch(err => {
      console.error('加载帖子列表失败', err);
    }).finally(() => {
      this.setData({ loading: false });
    });
  },

  // ========== 排序切换 ==========
  switchSort: function (e) {
    const sort = e.currentTarget.dataset.sort;
    this.setData({
      currentSort: sort,
      page: 1,
      posts: [],
      hasMore: true
    });
    this.loadPosts();
  },

  // ========== 点赞 ==========
  handleLike: function (e) {
    if (!app.checkAuth()) return;

    const postId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    const post = this.data.posts[index];
    const isLiked = !post.isLiked;
    const likes = isLiked ? post.likes + 1 : post.likes - 1;

    // 即时更新UI
    const posts = [...this.data.posts];
    posts[index].isLiked = isLiked;
    posts[index].likes = likes;
    this.setData({ posts });

    // 调用API
    const apiName = isLiked ? 'likePost' : 'unlikePost';
    api[apiName](postId).then(res => {
      if (res.code !== 0) {
        // 失败回滚
        const posts = [...this.data.posts];
        posts[index].isLiked = !isLiked;
        posts[index].likes = likes;
        this.setData({ posts });
        wx.showToast({ title: res.msg || '操作失败', icon: 'none' });
      }
    }).catch(err => {
      console.error('点赞失败', err);
    });
  },

  // ========== 收藏 ==========
  handleCollect: function (e) {
    if (!app.checkAuth()) return;

    const postId = e.currentTarget.dataset.id;
    const index = e.currentTarget.dataset.index;
    const post = this.data.posts[index];
    const isCollected = !post.isCollected;

    // 即时更新UI
    const posts = [...this.data.posts];
    posts[index].isCollected = isCollected;
    this.setData({ posts });

    // 调用API
    const apiName = isCollected ? 'collectPost' : 'uncollectPost';
    api[apiName](postId).then(res => {
      if (res.code === 0) {
        wx.showToast({
          title: isCollected ? '收藏成功' : '取消收藏',
          icon: 'success'
        });
      } else {
        // 失败回滚
        const posts = [...this.data.posts];
        posts[index].isCollected = !isCollected;
        this.setData({ posts });
      }
    }).catch(err => {
      console.error('收藏失败', err);
    });
  },

  // ========== 分享 ==========
  handleShare: function (e) {
    const postId = e.currentTarget.dataset.id;
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      const postId = res.target.dataset.id;
      return {
        title: '美妆教程分享',
        path: `/pages/community/postDetail/postDetail?id=${postId}`,
        imageUrl: res.target.dataset.image
      };
    }
    return {
      title: '美妆教程社区',
      path: '/pages/community/community'
    };
  },

  // ========== 跳转页面 ==========
  goToPostDetail: function (e) {
    const postId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/community/postDetail/postDetail?id=${postId}`
    });
  },

  goToPublish: function () {
    if (!app.checkAuth()) return;
    wx.navigateTo({
      url: '/pages/community/publish/publish'
    });
  },

  goToTopicDetail: function (e) {
    const topicId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/community/topicDetail/topicDetail?id=${topicId}`
    });
  },

  goToUserProfile: function (e) {
    const userId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/user/user?id=${userId}`
    });
  }
});
