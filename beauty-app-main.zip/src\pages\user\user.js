// pages/user/user.js
const api = require('../../api/api.js');
const app = getApp();

Page({
  data: {
    userId: null,
    user: null,

    // Tab
    tabs: ['笔记', '收藏', '课程'],
    activeTab: 0,

    // 内容列表
    posts: [],
    collections: [],
    courses: [],
    page: 1,
    pageSize: 10,
    hasMore: true,
    loading: false,

    // 是否是当前用户
    isOwner: false,

    // 用户信息
    currentUser: null
  },

  onLoad: function (options) {
    const userId = options.id;
    if (!userId) {
      wx.showToast({ title: '参数错误', icon: 'none' });
      wx.navigateBack();
      return;
    }

    this.setData({
      userId,
      currentUser: app.globalData.userInfo,
      isOwner: userId == app.globalData.userInfo?.id
    });

    this.loadUserProfile();
  },

  onShow: function () {
    this.setData({ currentUser: app.globalData.userInfo });
  },

  onTabChange: function (e) {
    const index = e.detail.index;
    this.setData({
      activeTab: index,
      page: 1,
      posts: [],
      collections: [],
      courses: [],
      hasMore: true
    });

    if (index === 0) {
      this.loadPosts();
    } else if (index === 1) {
      this.loadCollections();
    } else {
      this.loadCourses();
    }
  },

  // ========== 加载用户信息 ==========
  loadUserProfile: function () {
    api.getUserProfile(this.data.userId).then(res => {
      if (res.code === 0) {
        this.setData({ user: res.data });
        wx.setNavigationBarTitle({ title: res.data.nickname });
      }
    });

    // 加载默认Tab内容
    this.loadPosts();
  },

  // ========== 加载笔记 ==========
  loadPosts: function (loadMore = false) {
    if (this.data.loading || !this.isOwner) return;

    this.setData({ loading: true });

    const params = {
      userId: this.data.userId,
      page: loadMore ? this.data.page + 1 : 1,
      pageSize: this.data.pageSize
    };

    api.getUserPosts(params).then(res => {
      if (res.code === 0) {
        const newPosts = res.data.list || [];
        this.setData({
          posts: loadMore ? [...this.data.posts, ...newPosts] : newPosts,
          page: params.page,
          hasMore: newPosts.length >= this.data.pageSize
        });
      }
    }).finally(() => {
      this.setData({ loading: false });
    });
  },

  // ========== 加载收藏 ==========
  loadCollections: function (loadMore = false) {
    if (this.data.loading) return;

    this.setData({ loading: true });

    const params = {
      page: loadMore ? this.data.page + 1 : 1,
      pageSize: this.data.pageSize
    };

    api.getMyCollections(params).then(res => {
      if (res.code === 0) {
        const newCollections = res.data.list || [];
        this.setData({
          collections: loadMore ? [...this.data.collections, ...newCollections] : newCollections,
          page: params.page,
          hasMore: newCollections.length >= this.data.pageSize
        });
      }
    }).finally(() => {
      this.setData({ loading: false });
    });
  },

  // ========== 加载课程 ==========
  loadCourses: function (loadMore = false) {
    if (this.data.loading) return;

    this.setData({ loading: true });

    const params = {
      userId: this.data.userId,
      page: loadMore ? this.data.page + 1 : 1,
      pageSize: this.data.pageSize
    };

    api.getUserCourses(params).then(res => {
      if (res.code === 0) {
        const newCourses = res.data.list || [];
        this.setData({
          courses: loadMore ? [...this.data.courses, ...newCourses] : newCourses,
          page: params.page,
          hasMore: newCourses.length >= this.data.pageSize
        });
      }
    }).finally(() => {
      this.setData({ loading: false });
    });
  },

  onReachBottom: function () {
    if (!this.data.hasMore || this.data.loading) return;

    if (this.data.activeTab === 0) {
      this.loadPosts(true);
    } else if (this.data.activeTab === 1) {
      this.loadCollections(true);
    } else {
      this.loadCourses(true);
    }
  },

  // ========== 关注/取关 ==========
  handleFollow: function () {
    if (!app.checkAuth()) return;

    const user = this.data.user;
    const isFollow = !user.isFollow;

    this.setData({ 'user.isFollow': isFollow });

    const apiName = isFollow ? 'followUser' : 'unfollowUser';
    api[apiName](this.data.userId).then(res => {
      if (res.code === 0) {
        wx.showToast({
          title: isFollow ? '关注成功' : '取消关注',
          icon: 'success'
        });
      } else {
        this.setData({ 'user.isFollow': !isFollow });
      }
    });
  },

  // ========== 跳转 ==========
  goToPostDetail: function (e) {
    const postId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/community/postDetail/postDetail?id=${postId}`
    });
  },

  goToCourseDetail: function (e) {
    const courseId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/courseDetail/courseDetail?id=${courseId}`
    });
  },

  goToSettings: function () {
    wx.navigateTo({
      url: '/pages/settings/settings'
    });
  }
});
