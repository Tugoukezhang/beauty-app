// pages/community/publish/publish.js
const api = require('../../../api/api.js');
const app = getApp();

Page({
  data: {
    // 内容
    content: '',
    contentLength: 0,
    maxLength: 1000,

    // 图片/视频
    images: [],
    videos: [],
    maxImages: 9,
    maxVideos: 1,

    // 话题
    topics: [],
    selectedTopic: null,
    showTopicPicker: false,

    // @用户
    atUsers: [],
    showAtPicker: false,

    // 位置
    location: '',
    showLocationPicker: false,

    // 可见性
    visibilityOptions: [
      { id: 'public', name: '公开', icon: '/assets/icons/world.png' },
      { id: 'friends', name: '好友可见', icon: '/assets/icons/team.png' },
      { id: 'private', name: '仅自己', icon: '/assets/icons/lock.png' }
    ],
    visibility: 'public',

    // 提交状态
    isSubmitting: false
  },

  onLoad: function (options) {
    // 如果从话题页进入，预选话题
    if (options.topicId) {
      this.setData({ selectedTopic: { id: options.topicId, name: options.topicName } });
    }

    // 加载话题列表
    this.loadTopics();
  },

  // ========== 内容输入 ==========
  onContentInput: function (e) {
    const value = e.detail.value;
    this.setData({
      content: value,
      contentLength: value.length
    });
  },

  // ========== 图片上传 ==========
  chooseImage: function () {
    const remain = this.data.maxImages - this.data.images.length;
    if (remain <= 0) {
      wx.showToast({ title: '最多上传9张图片', icon: 'none' });
      return;
    }

    wx.chooseMedia({
      count: remain,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const newImages = res.tempFiles.map(f => f.tempFilePath);
        this.uploadImages([...this.data.images, ...newImages]);
      }
    });
  },

  // 上传图片到服务器
  uploadImages: function (localPaths) {
    wx.showLoading({ title: '上传中...' });

    const uploadPromises = localPaths.map(path => {
      return new Promise((resolve, reject) => {
        wx.uploadFile({
          url: api.getUploadUrl(),
          filePath: path,
          name: 'file',
          header: { 'Authorization': 'Bearer ' + app.globalData.token },
          success: (res) => {
            const data = JSON.parse(res.data);
            if (data.code === 0) {
              resolve(data.data.url);
            } else {
              reject(new Error(data.msg));
            }
          },
          fail: reject
        });
      });
    });

    Promise.all(uploadPromises)
      .then(urls => {
        wx.hideLoading();
        this.setData({ images: urls });
      })
      .catch(err => {
        wx.hideLoading();
        wx.showToast({ title: '上传失败', icon: 'none' });
        console.error('上传图片失败', err);
      });
  },

  // 删除图片
  removeImage: function (e) {
    const index = e.currentTarget.dataset.index;
    const images = [...this.data.images];
    images.splice(index, 1);
    this.setData({ images });
  },

  // 预览图片
  previewImage: function (e) {
    const url = e.currentTarget.dataset.url;
    wx.previewImage({
      current: url,
      urls: this.data.images
    });
  },

  // ========== 视频上传 ==========
  chooseVideo: function () {
    if (this.data.videos.length >= this.data.maxVideos) {
      wx.showToast({ title: '最多上传1个视频', icon: 'none' });
      return;
    }

    wx.chooseMedia({
      count: 1,
      mediaType: ['video'],
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      success: (res) => {
        const videoPath = res.tempFiles[0].tempFilePath;
        this.uploadVideo(videoPath);
      }
    });
  },

  uploadVideo: function (localPath) {
    wx.showLoading({ title: '上传中...' });

    wx.uploadFile({
      url: api.getUploadUrl(),
      filePath: localPath,
      name: 'file',
      header: { 'Authorization': 'Bearer ' + app.globalData.token },
      success: (res) => {
        wx.hideLoading();
        const data = JSON.parse(res.data);
        if (data.code === 0) {
          this.setData({
            videos: [{ url: data.data.url, cover: data.data.cover }]
          });
        } else {
          wx.showToast({ title: data.msg || '上传失败', icon: 'none' });
        }
      },
      fail: () => {
        wx.hideLoading();
        wx.showToast({ title: '上传失败', icon: 'none' });
      }
    });
  },

  removeVideo: function () {
    this.setData({ videos: [] });
  },

  // ========== 话题 ==========
  loadTopics: function () {
    api.getCommunityTopics().then(res => {
      if (res.code === 0) {
        this.setData({ topics: res.data || [] });
      }
    });
  },

  toggleTopicPicker: function () {
    this.setData({ showTopicPicker: !this.data.showTopicPicker });
  },

  selectTopic: function (e) {
    const topic = e.currentTarget.dataset.topic;
    this.setData({
      selectedTopic: topic,
      showTopicPicker: false
    });
  },

  clearTopic: function () {
    this.setData({ selectedTopic: null });
  },

  // ========== @用户 ==========
  onAtTap: function () {
    this.setData({ showAtPicker: true });
    this.loadAtUsers();
  },

  loadAtUsers: function () {
    // 获取最近互动用户
    api.getRecentUsers().then(res => {
      if (res.code === 0) {
        this.setData({ atUsers: res.data || [] });
      }
    });
  },

  selectAtUser: function (e) {
    const user = e.currentTarget.dataset.user;
    const content = this.data.content + '@' + user.nickname + ' ';
    this.setData({
      content,
      contentLength: content.length,
      showAtPicker: false
    });
  },

  // ========== 位置 ==========
  chooseLocation: function () {
    wx.chooseLocation({
      success: (res) => {
        this.setData({ location: res.name });
      }
    });
  },

  clearLocation: function () {
    this.setData({ location: '' });
  },

  // ========== 可见性 ==========
  selectVisibility: function (e) {
    const visibility = e.currentTarget.dataset.id;
    this.setData({ visibility });
  },

  // ========== 提交 ==========
  submit: function () {
    // 验证
    if (!this.data.content.trim() && this.data.images.length === 0 && this.data.videos.length === 0) {
      wx.showToast({ title: '请输入内容或上传图片/视频', icon: 'none' });
      return;
    }

    if (this.data.isSubmitting) return;

    this.setData({ isSubmitting: true });

    const params = {
      content: this.data.content,
      images: this.data.images,
      videos: this.data.videos,
      topicId: this.data.selectedTopic?.id || null,
      location: this.data.location,
      visibility: this.data.visibility
    };

    api.publishPost(params).then(res => {
      if (res.code === 0) {
        wx.showToast({ title: '发布成功', icon: 'success' });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
      } else {
        wx.showToast({ title: res.msg || '发布失败', icon: 'none' });
      }
    }).catch(err => {
      wx.showToast({ title: '发布失败', icon: 'none' });
      console.error('发布失败', err);
    }).finally(() => {
      this.setData({ isSubmitting: false });
    });
  },

  // ========== 保存草稿 ==========
  saveDraft: function () {
    wx.setStorageSync('postDraft', {
      content: this.data.content,
      images: this.data.images,
      topicId: this.data.selectedTopic?.id || null,
      updateTime: Date.now()
    });
    wx.showToast({ title: '草稿已保存', icon: 'success' });
  }
});
