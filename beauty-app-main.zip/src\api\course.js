/**
 * 课程相关接口
 * @description 课程列表、详情、购买、学习相关API
 */

const { get, post } = require('./request');

/**
 * 获取课程分类
 */
export function getCourseCategories() {
  return get('/api/course/categories');
}

/**
 * 获取课程列表
 * @param {Object} params 查询参数
 * @param {number} params.categoryId 分类ID
 * @param {string} params.keyword 关键词
 * @param {string} params.sort 排序: new/hot/price
 * @param {number} params.page 页码
 * @param {number} params.pageSize 每页数量
 */
export function getCourseList(params = {}) {
  return get('/api/course/list', params);
}

/**
 * 获取课程详情
 * @param {number} courseId 课程ID
 */
export function getCourseDetail(courseId) {
  return get('/api/course/detail', { courseId });
}

/**
 * 获取课程章节列表
 * @param {number} courseId 课程ID
 */
export function getCourseChapters(courseId) {
  return get('/api/course/chapters', { courseId });
}

/**
 * 获取课程评论列表
 * @param {number} courseId 课程ID
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getCourseComments(courseId, page = 1, pageSize = 10) {
  return get('/api/course/comments', { courseId, page, pageSize });
}

/**
 * 添加课程评论
 * @param {number} courseId 课程ID
 * @param {number} rating 评分 1-5
 * @param {string} content 评论内容
 * @param {number} parentId 父评论ID（回复）
 */
export function addCourseComment(courseId, rating, content, parentId = 0) {
  return post('/api/course/comment/add', { courseId, rating, content, parentId });
}

/**
 * 检查课程购买状态
 * @param {number} courseId 课程ID
 */
export function checkCoursePurchased(courseId) {
  return get('/api/course/check-purchased', { courseId });
}

/**
 * 获取课程学习进度
 * @param {number} courseId 课程ID
 */
export function getCourseProgress(courseId) {
  return get('/api/course/progress', { courseId });
}

/**
 * 更新学习进度
 * @param {number} courseId 课程ID
 * @param {number} chapterId 章节ID
 * @param {number} progress 进度百分比
 */
export function updateLearnProgress(courseId, chapterId, progress) {
  return post('/api/course/progress/update', { courseId, chapterId, progress });
}

/**
 * 获取章节视频播放凭证
 * @param {number} chapterId 章节ID
 */
export function getChapterPlayUrl(chapterId) {
  return get('/api/course/chapter/play-url', { chapterId });
}

/**
 * 创建课程订单
 * @param {number} courseId 课程ID
 * @param {string} payMethod 支付方式: wxpay/points
 */
export function createCourseOrder(courseId, payMethod = 'wxpay') {
  return post('/api/course/order/create', { courseId, payMethod });
}

/**
 * 获取老师详情
 * @param {number} teacherId 老师ID
 */
export function getTeacherDetail(teacherId) {
  return get('/api/teacher/detail', { teacherId });
}

/**
 * 获取老师的课程列表
 * @param {number} teacherId 老师ID
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getTeacherCourses(teacherId, page = 1, pageSize = 10) {
  return get('/api/teacher/courses', { teacherId, page, pageSize });
}

/**
 * 关注老师
 * @param {number} teacherId 老师ID
 */
export function followTeacher(teacherId) {
  return post('/api/teacher/follow', { teacherId });
}

/**
 * 取消关注老师
 * @param {number} teacherId 老师ID
 */
export function unfollowTeacher(teacherId) {
  return post('/api/teacher/unfollow', { teacherId });
}

/**
 * 获取我的课程列表
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getMyCourses(page = 1, pageSize = 10) {
  return get('/api/course/my-list', { page, pageSize });
}

/**
 * 获取课程工具清单
 * @param {number} courseId 课程ID
 */
export function getCourseTools(courseId) {
  return get('/api/course/tools', { courseId });
}

/**
 * 获取推荐课程
 * @param {number} courseId 当前课程ID（排除）
 * @param {number} limit 数量
 */
export function getRecommendCourses(courseId, limit = 6) {
  return get('/api/course/recommend', { courseId, limit });
}

/**
 * 获取热门课程
 * @param {number} limit 数量
 */
export function getHotCourses(limit = 10) {
  return get('/api/course/hot', { limit });
}

/**
 * 获取新课列表
 * @param {number} limit 数量
 */
export function getNewCourses(limit = 10) {
  return get('/api/course/new', { limit });
}
