/**
 * 用户相关接口
 * @description 用户登录、个人信息、会员相关API
 */

const { get, post } = require('./request');

/**
 * 微信登录
 * @param {string} code 微信授权码
 */
export function wxLogin(code) {
  return post('/api/user/wx-login', { code });
}

/**
 * 手机号登录
 * @param {string} phone 手机号
 * @param {string} code 验证码
 */
export function phoneLogin(phone, code) {
  return post('/api/user/phone-login', { phone, code });
}

/**
 * 获取用户信息
 */
export function getUserInfo() {
  return get('/api/user/info');
}

/**
 * 更新用户信息
 * @param {Object} data 用户信息
 */
export function updateUserInfo(data) {
  return post('/api/user/update', data);
}

/**
 * 获取用户学习记录
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getLearningHistory(page = 1, pageSize = 10) {
  return get('/api/user/learning-history', { page, pageSize });
}

/**
 * 获取用户收藏
 * @param {string} type 收藏类型: course/video/post
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getUserCollections(type, page = 1, pageSize = 10) {
  return get('/api/user/collections', { type, page, pageSize });
}

/**
 * 添加收藏
 * @param {string} type 收藏类型
 * @param {number} id 收藏对象ID
 */
export function addCollection(type, id) {
  return post('/api/user/collection/add', { type, id });
}

/**
 * 取消收藏
 * @param {string} type 收藏类型
 * @param {number} id 收藏对象ID
 */
export function cancelCollection(type, id) {
  return post('/api/user/collection/cancel', { type, id });
}

/**
 * 获取用户积分
 */
export function getUserPoints() {
  return get('/api/user/points');
}

/**
 * 获取用户积分明细
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getPointsDetail(page = 1, pageSize = 20) {
  return get('/api/user/points-detail', { page, pageSize });
}

/**
 * 获取会员信息
 */
export function getVipInfo() {
  return get('/api/user/vip-info');
}

/**
 * 获取签到信息
 */
export function getSignInfo() {
  return get('/api/user/sign-info');
}

/**
 * 签到
 */
export function doSign() {
  return post('/api/user/sign');
}

/**
 * 获取邀请码
 */
export function getInviteCode() {
  return get('/api/user/invite-code');
}

/**
 * 获取邀请列表
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getInviteList(page = 1, pageSize = 20) {
  return get('/api/user/invite-list', { page, pageSize });
}

/**
 * 获取订单列表
 * @param {string} type 订单类型: course/recharge
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getOrderList(type, page = 1, pageSize = 10) {
  return get('/api/order/list', { type, page, pageSize });
}

/**
 * 申请退款
 * @param {number} orderId 订单ID
 * @param {string} reason 退款原因
 */
export function applyRefund(orderId, reason) {
  return post('/api/order/refund', { orderId, reason });
}

/**
 * 获取消息列表
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getMessageList(page = 1, pageSize = 20) {
  return get('/api/user/message-list', { page, pageSize });
}

/**
 * 获取未读消息数
 */
export function getUnreadCount() {
  return get('/api/user/unread-count');
}

/**
 * 阅读消息
 * @param {number} messageId 消息ID
 */
export function readMessage(messageId) {
  return post('/api/user/message/read', { messageId });
}
