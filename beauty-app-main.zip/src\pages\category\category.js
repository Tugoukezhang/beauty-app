/**
 * 课程分类页面
 * 功能：分类列表、筛选排序、热门推荐
 */

const courseApi = require('../../api/course');

Page({
  data: {
    // 左侧分类
    categories: [],
    activeCategoryId: 0,
    // 右侧内容
    subCategories: [],
    hotCourses: [],
    // 筛选条件
    filters: [
      { id: 'default', name: '综合', active: true },
      { id: 'hot', name: '最热', active: false },
      { id: 'new', name: '最新', active: false },
      { id: 'price_asc', name: '价格↑', active: false },
      { id: 'price_desc', name: '价格↓', active: false }
    ],
    sortBy: 'default',
    // 加载状态
    loading: false
  },

  onLoad() {
    this.loadCategories();
  },

  onShow() {},

  onPullDownRefresh() {
    this.loadCategories();
    wx.stopPullDownRefresh();
  },

  // 加载分类数据
  async loadCategories() {
    this.setData({ loading: true });

    try {
      const result = await courseApi.getCategories();
      const categories = result.list || this.getMockCategories();

      this.setData({
        categories,
        activeCategoryId: categories[0]?.id || 1
      });

      this.loadSubCategories();
      this.loadHotCourses();
    } catch (err) {
      // 使用模拟数据
      this.setMockData();
    } finally {
      this.setData({ loading: false });
    }
  },

  // 获取模拟分类
  getMockCategories() {
    return [
      { id: 1, name: '新娘妆', icon: '/assets/icons/category-bride.png', count: 128 },
      { id: 2, name: '古风妆', icon: '/assets/icons/category-ancient.png', count: 96 },
      { id: 3, name: '日常妆', icon: '/assets/icons/category-daily.png', count: 256 },
      { id: 4, name: '宴会妆', icon: '/assets/icons/category-party.png', count: 84 },
      { id: 5, name: 'Cosplay', icon: '/assets/icons/category-cos.png', count: 72 },
      { id: 6, name: '影视特效', icon: '/assets/icons/category-film.png', count: 48 },
      { id: 7, name: '美甲', icon: '/assets/icons/category-nail.png', count: 156 },
      { id: 8, name: '护肤', icon: '/assets/icons/category-skincare.png', count: 189 }
    ];
  },

  // 设置模拟数据
  setMockData() {
    this.setData({
      categories: this.getMockCategories(),
      subCategories: this.getMockSubCategories(1),
      hotCourses: this.getMockHotCourses()
    });
  },

  // 获取子分类模拟数据
  getMockSubCategories(parentId) {
    const subMap = {
      1: [{ id: 11, name: '中式新娘' }, { id: 12, name: '西式新娘' }, { id: 13, name: '韩式新娘' }],
      2: [{ id: 21, name: '唐妆' }, { id: 22, name: '汉服妆' }, { id: 23, name: '清宫妆' }],
      3: [{ id: 31, name: '通勤妆' }, { id: 32, name: '学生妆' }, { id: 33, name: '约会妆' }],
      4: [{ id: 41, name: '晚宴妆' }, { id: 42, name: '派对妆' }],
      5: [{ id: 51, name: '日漫' }, { id: 52, name: '国漫' }, { id: 53, name: '游戏' }],
      6: [{ id: 61, name: '伤效妆' }, { id: 62, name: '老年妆' }],
      7: [{ id: 71, name: '美甲款式' }, { id: 72, name: '护理' }],
      8: [{ id: 81, name: '日常护肤' }, { id: 82, name: '功效护肤' }]
    };
    return subMap[parentId] || [];
  },

  // 获取热门课程模拟数据
  getMockHotCourses() {
    return [
      {
        id: 101,
        title: '新娘妆入门必修课',
        cover: '/assets/images/course-cover-1.png',
        teacher: '美妆导师Lily',
        price: 299,
        originalPrice: 599,
        studyCount: 12580,
        rating: 4.9,
        isFree: false
      },
      {
        id: 102,
        title: '古风妆容设计教程',
        cover: '/assets/images/course-cover-2.png',
        teacher: '古风化妆师小雪',
        price: 199,
        originalPrice: 399,
        studyCount: 8932,
        rating: 4.8,
        isFree: false
      },
      {
        id: 103,
        title: '日常通勤妆容技巧',
        cover: '/assets/images/course-cover-3.png',
        teacher: '美妆博主Amy',
        price: 0,
        originalPrice: 0,
        studyCount: 25680,
        rating: 4.7,
        isFree: true
      }
    ];
  },

  // 选择分类
  onCategoryTap(e) {
    const { id } = e.currentTarget.dataset;
    if (id === this.data.activeCategoryId) return;

    this.setData({
      activeCategoryId: id,
      subCategories: this.getMockSubCategories(id)
    });

    this.loadCoursesByCategory(id);
  },

  // 选择子分类
  onSubCategoryTap(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({
      url: `/pages/courseList/courseList?categoryId=${this.data.activeCategoryId}&subCategoryId=${id}`
    });
  },

  // 查看全部
  viewAll() {
    wx.navigateTo({
      url: `/pages/courseList/courseList?categoryId=${this.data.activeCategoryId}`
    });
  },

  // 切换筛选
  onFilterTap(e) {
    const { id } = e.currentTarget.dataset;
    const filters = this.data.filters.map(f => ({
      ...f,
      active: f.id === id
    }));

    this.setData({ filters, sortBy: id });
    this.loadCoursesByCategory(this.data.activeCategoryId);
  },

  // 加载该分类下的课程
  async loadCoursesByCategory(categoryId) {
    try {
      const result = await courseApi.getCourseList({
        categoryId,
        sortBy: this.data.sortBy
      });
      this.setData({ hotCourses: result.list || [] });
    } catch (err) {
      this.setData({ hotCourses: this.getMockHotCourses() });
    }
  },

  // 加载子分类
  loadSubCategories() {
    this.setData({
      subCategories: this.getMockSubCategories(this.data.activeCategoryId)
    });
  },

  // 加载热门课程
  loadHotCourses() {
    this.setData({ hotCourses: this.getMockHotCourses() });
  },

  // 跳转到课程详情
  goToCourse(e) {
    const { id } = e.currentTarget.dataset;
    wx.navigateTo({ url: `/pages/courseDetail/courseDetail?id=${id}` });
  }
});
