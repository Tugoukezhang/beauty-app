/**
 * 社区相关接口
 * @description 社区帖子、评论、点赞相关API
 */

const { get, post } = require('./request');

/**
 * 获取话题列表
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getTopics(page = 1, pageSize = 20) {
  return get('/api/community/topics', { page, pageSize });
}

/**
 * 获取热门话题
 * @param {number} limit 数量
 */
export function getHotTopics(limit = 10) {
  return get('/api/community/hot-topics', { limit });
}

/**
 * 获取帖子列表
 * @param {Object} params 查询参数
 * @param {string} params.type 类型: all/follow/favorite
 * @param {number} params.topicId 话题ID
 * @param {string} params.keyword 关键词
 * @param {string} params.sort 排序: new/hot
 * @param {number} params.page 页码
 * @param {number} params.pageSize 每页数量
 */
export function getPostList(params = {}) {
  return get('/api/community/posts', params);
}

/**
 * 获取帖子详情
 * @param {number} postId 帖子ID
 */
export function getPostDetail(postId) {
  return get('/api/community/post/detail', { postId });
}

/**
 * 发布帖子
 * @param {Object} data 帖子数据
 * @param {string} data.content 文字内容
 * @param {string[]} data.images 图片列表
 * @param {string} data.video 视频URL
 * @param {number} data.topicId 话题ID
 * @param {number[]} data.productIds 关联商品ID
 */
export function publishPost(data) {
  return post('/api/community/post/publish', data);
}

/**
 * 删除帖子
 * @param {number} postId 帖子ID
 */
export function deletePost(postId) {
  return post('/api/community/post/delete', { postId });
}

/**
 * 点赞帖子
 * @param {number} postId 帖子ID
 */
export function likePost(postId) {
  return post('/api/community/post/like', { postId });
}

/**
 * 取消点赞
 * @param {number} postId 帖子ID
 */
export function unlikePost(postId) {
  return post('/api/community/post/unlike', { postId });
}

/**
 * 收藏帖子
 * @param {number} postId 帖子ID
 */
export function favoritePost(postId) {
  return post('/api/community/post/favorite', { postId });
}

/**
 * 取消收藏帖子
 * @param {number} postId 帖子ID
 */
export function unfavoritePost(postId) {
  return post('/api/community/post/unfavorite', { postId });
}

/**
 * 获取帖子评论列表
 * @param {number} postId 帖子ID
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getPostComments(postId, page = 1, pageSize = 20) {
  return get('/api/community/comments', { postId, page, pageSize });
}

/**
 * 添加评论
 * @param {number} postId 帖子ID
 * @param {string} content 评论内容
 * @param {number} parentId 父评论ID（回复）
 */
export function addComment(postId, content, parentId = 0) {
  return post('/api/community/comment/add', { postId, content, parentId });
}

/**
 * 删除评论
 * @param {number} commentId 评论ID
 */
export function deleteComment(commentId) {
  return post('/api/community/comment/delete', { commentId });
}

/**
 * 举报帖子
 * @param {number} postId 帖子ID
 * @param {string} type 举报类型
 * @param {string} reason 举报原因
 */
export function reportPost(postId, type, reason) {
  return post('/api/community/post/report', { postId, type, reason });
}

/**
 * 举报评论
 * @param {number} commentId 评论ID
 * @param {string} type 举报类型
 * @param {string} reason 举报原因
 */
export function reportComment(commentId, type, reason) {
  return post('/api/community/comment/report', { commentId, type, reason });
}

/**
 * 获取我的帖子列表
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getMyPosts(page = 1, pageSize = 10) {
  return get('/api/community/my-posts', { page, pageSize });
}

/**
 * 获取我点赞的帖子列表
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getMyLikedPosts(page = 1, pageSize = 10) {
  return get('/api/community/my-liked-posts', { page, pageSize });
}

/**
 * 获取我收藏的帖子列表
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getMyFavoritePosts(page = 1, pageSize = 10) {
  return get('/api/community/my-favorite-posts', { page, pageSize });
}

/**
 * 分享帖子
 * @param {number} postId 帖子ID
 */
export function sharePost(postId) {
  return post('/api/community/post/share', { postId });
}

/**
 * 获取话题详情
 * @param {number} topicId 话题ID
 */
export function getTopicDetail(topicId) {
  return get('/api/community/topic/detail', { topicId });
}

/**
 * 获取话题帖子列表
 * @param {number} topicId 话题ID
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getTopicPosts(topicId, page = 1, pageSize = 20) {
  return get('/api/community/topic/posts', { topicId, page, pageSize });
}

// ========== 补充接口 ==========

/**
 * 获取社区话题分类
 */
export function getCommunityTopics() {
  return get('/api/community/topics');
}

/**
 * 获取话题广场列表
 */
export function getTopicsList() {
  return get('/api/community/topic-square');
}

/**
 * 评论帖子
 * @param {Object} params 参数
 */
export function addComment(params) {
  return post('/api/community/comment/add', params);
}

/**
 * 获取评论列表
 * @param {Object} params 参数
 */
export function getCommentList(params) {
  return get('/api/community/comments', params);
}

/**
 * 评论点赞
 * @param {number} commentId 评论ID
 */
export function likeComment(commentId) {
  return post('/api/community/comment/like', { commentId });
}

/**
 * 取消评论点赞
 * @param {number} commentId 评论ID
 */
export function unlikeComment(commentId) {
  return post('/api/community/comment/unlike', { commentId });
}

/**
 * 收藏帖子
 * @param {number} postId 帖子ID
 */
export function collectPost(postId) {
  return post('/api/community/post/collect', { postId });
}

/**
 * 取消收藏帖子
 * @param {number} postId 帖子ID
 */
export function uncollectPost(postId) {
  return post('/api/community/post/uncollect', { postId });
}

/**
 * 获取最近互动用户
 */
export function getRecentUsers() {
  return get('/api/community/recent-users');
}

/**
 * 关注用户
 * @param {number} userId 用户ID
 */
export function followUser(userId) {
  return post('/api/user/follow', { userId });
}

/**
 * 取消关注用户
 * @param {number} userId 用户ID
 */
export function unfollowUser(userId) {
  return post('/api/user/unfollow', { userId });
}

/**
 * 获取用户主页信息
 * @param {number} userId 用户ID
 */
export function getUserProfile(userId) {
  return get('/api/user/profile', { userId });
}

/**
 * 获取用户帖子列表
 * @param {Object} params 参数
 */
export function getUserPosts(params) {
  return get('/api/user/posts', params);
}

/**
 * 获取用户收藏列表
 * @param {Object} params 参数
 */
export function getMyCollections(params) {
  return get('/api/user/collections', params);
}

/**
 * 获取用户课程列表
 * @param {Object} params 参数
 */
export function getUserCourses(params) {
  return get('/api/user/courses', params);
}
