/**
 * 支付相关接口
 * @description 充值、支付、订单相关API
 */

const { get, post } = require('./request');

/**
 * 获取充值档位列表
 */
export function getRechargePackages() {
  return get('/api/payment/recharge-packages');
}

/**
 * 创建充值订单
 * @param {number} packageId 档位ID
 */
export function createRechargeOrder(packageId) {
  return post('/api/payment/recharge/create', { packageId });
}

/**
 * 发起微信支付
 * @param {number} orderId 订单ID
 */
export function wxPay(orderId) {
  return post('/api/payment/wx-pay', { orderId });
}

/**
 * 支付结果查询
 * @param {number} orderId 订单ID
 */
export function getPayResult(orderId) {
  return get('/api/payment/pay-result', { orderId });
}

/**
 * 获取订单详情
 * @param {number} orderId 订单ID
 */
export function getOrderDetail(orderId) {
  return get('/api/order/detail', { orderId });
}

/**
 * 取消订单
 * @param {number} orderId 订单ID
 */
export function cancelOrder(orderId) {
  return post('/api/order/cancel', { orderId });
}

/**
 * 申请退款
 * @param {number} orderId 订单ID
 * @param {string} reason 退款原因
 */
export function applyRefund(orderId, reason) {
  return post('/api/order/refund/apply', { orderId, reason });
}

/**
 * 获取退款进度
 * @param {number} refundId 退款ID
 */
export function getRefundProgress(refundId) {
  return get('/api/order/refund/progress', { refundId });
}

/**
 * 获取用户余额（妆币）
 */
export function getUserBalance() {
  return get('/api/payment/balance');
}

/**
 * 获取用户余额明细
 * @param {number} page 页码
 * @param {number} pageSize 每页数量
 */
export function getBalanceDetail(page = 1, pageSize = 20) {
  return get('/api/payment/balance-detail', { page, pageSize });
}

/**
 * 发送短信验证码
 * @param {string} phone 手机号
 * @param {string} type 验证码类型: login/register
 */
export function sendSmsCode(phone, type = 'login') {
  return post('/api/sms/send', { phone, type });
}

/**
 * 验证短信验证码
 * @param {string} phone 手机号
 * @param {string} code 验证码
 */
export function verifySmsCode(phone, code) {
  return post('/api/sms/verify', { phone, code });
}
